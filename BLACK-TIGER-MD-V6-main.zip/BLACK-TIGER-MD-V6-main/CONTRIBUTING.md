worker: npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
