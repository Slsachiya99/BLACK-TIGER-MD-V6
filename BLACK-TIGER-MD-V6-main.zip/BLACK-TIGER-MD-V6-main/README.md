# BLACK-TIGER-MD-V6


[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&size=40&pause=1000&color=22F700&multiline=true&width=435&height=53&lines=~*%E2%99%B2%E2%9D%83BLACK-TIGER-MD-V6%E2%9D%83%E2%99%B2*~+%E0%B7%84%E0%B7%8F%E0%B6%BA%E0%B7%92+SL+SACHIYA+TM%E2%99%B2%E2%9D%83BLACK+TIGER+MD+V6+SRI+LANKA)](https://git.io/typing-svg)



~*♲❃BLACK-TIGER-MD-V6❃♲*~


<img src="https://i.imgur.com/XHhlqtK.jpeg" alt="GIF" width="700"/>

</p>
##

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=E13EF7&background=FF468A00&width=435&lines=SACHIYA+MD+WA+BOT+SRI+LANKA++)](https://git.io/typing-svg)

### QR CODE

. Click [SCAN](https://replit.com/@Slsachiya99/BLACK-TIGER-MD-V1-3?v=1) and scan QR through Whatsapp Linked Devices Option in Your WhatsApp App.


2. Click [FORK](https://github.com/Slsachiya99/BLACK-TIGER-MD-V6/fork)

3. If You don't have a account in [Heroku](https://signup.heroku.com/), Create a account.

4. Then Click [DEPLOY](https://heroku.com/deploy) Button To Enjoy My Bot.


## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=WELCOME+TO+BLACK+TIGER+MD+WA+BOT.;CREATED+BY+SACHIYA+TM;BEST+MULTIDEVICE+WA+BOT;THANKS+FOR+VISITING+MY+GIT)](https://git.io/typing-svg)



<img src="https://i.imgur.com/XHhlqtK.jpeg" alt="GIF" width="700"/>


## [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Rockstar-ExtraBold&color=F33A6A&lines=ආයුබොවන්+TO+BLACK+TIGER+MD+WA+BOT.;CREATED+BY+SACHIYA+TM;BEST+MULTIDEVICE+WA+BOT;THANKS+FOR+VISITING+MY+GIT+ඉතින්+කොහොමද😁+මොකද+කරන්නෙ)


https://user-images.githubusercontent.com/115049370/195422779-6f43b3fb-b9c8-4329-a5ea-d75d3bb1394e.mp4



~*♲❃BLACK-TIGER-MD-V6❃♲*~


