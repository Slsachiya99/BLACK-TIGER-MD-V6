{

    "OWNER" : "SACHIYA-MD",

    "NUMBER" : "+94718181282",

    "YT_CHANNEL" : "🌐",

    "BLOCK_CHAT" : "120363043598019970@g.us",

    "img" : "https://i.imgur.com/XHhlqtK.jpeg",

    "support" : "https://chat.whatsapp.com/JLqwVWcONTkFRRfW89IcR5",

    "logmsg" : "_SACHIYA-MD Bot Now Working ❃_\n\n*_👋 HI welcome to SACHIYA-MD bot Thanks To 💗🙌_*\n\n🔮 *_කරුණාකර මෙහි ප්ලගීන උත්සාහ නොකරන්න. මෙය ඔබගේ ලොග් අංකයයි. ⚙ ඔබට ඕනෑම චැට් එකක විධාන උත්සාහ කළ හැකිය*",

    "SCRIPT" : "*👸🏻 Thanaks fro using SACHIYA MD Script ||",

    "THUMB" : "https://i.imgur.com/XHhlqtK.jpeg",

    "~*♲❃BLACK-TIGER-MD-V6❃♲*~"

  }
